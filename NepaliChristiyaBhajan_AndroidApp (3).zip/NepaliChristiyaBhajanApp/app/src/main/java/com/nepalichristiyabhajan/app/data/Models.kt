package com.nepalichristiyabhajan.app.data

import kotlinx.serialization.Serializable

@Serializable
data class SongbookData(
    val title: String,
    val lordsPrayer: LordsPrayer,
    val categories: List<SongCategory>,
    val songs: List<Song>
)

@Serializable
data class LordsPrayer(
    val titleNepali: String,
    val titleEnglish: String,
    val reference: String,
    val nepali: String,
    val english: String
)

@Serializable
data class SongCategory(
    val id: String,
    val index: Int,
    val name: String,
    val songNumbers: List<Int>
)

@Serializable
data class Song(
    val id: String,
    val section: String,
    val number: Int,
    val numberNepali: String,
    val title: String,
    val englishTitle: String? = null,
    val scale: String? = null,
    val rhythm: String? = null,
    val categoryIds: List<String> = emptyList(),
    val page: Int = 0,
    val lyrics: String
)

enum class SongSection(val key: String, val nepaliLabel: String, val englishLabel: String) {
    BHAJAN("bhajan", "भजन", "Bhajans"),
    CHORUS("chorus", "कोरस", "Choruses"),
    CHILD_CHORUS("child_chorus", "बाल कोरस", "Child Choruses"),
    FAVORITES("favorites", "मनपर्ने", "Favorites")
}
