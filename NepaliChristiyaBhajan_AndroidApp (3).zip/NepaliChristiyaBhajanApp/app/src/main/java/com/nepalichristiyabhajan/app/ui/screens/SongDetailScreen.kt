package com.nepalichristiyabhajan.app.ui.screens

import android.app.Activity
import android.content.Intent
import android.view.WindowManager
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TextDecrease
import androidx.compose.material.icons.filled.TextIncrease
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nepalichristiyabhajan.app.data.Song
import com.nepalichristiyabhajan.app.data.SongCategory

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SongDetailScreen(
    song: Song?,
    categories: List<SongCategory>,
    isFavorite: Boolean,
    fontSizeSp: Float,
    keepScreenOn: Boolean,
    prevSongId: String?,
    nextSongId: String?,
    onBack: () -> Unit,
    onToggleFavorite: () -> Unit,
    onAdjustFontSize: (Float) -> Unit,
    onToggleKeepScreenOn: () -> Unit,
    onNavigateToSong: (String) -> Unit
) {
    val context = LocalContext.current

    // Keep screen on while reading lyrics if enabled
    DisposableEffect(keepScreenOn) {
        val window = (context as? Activity)?.window
        if (keepScreenOn) {
            window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        onDispose {
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    if (song == null) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("भजन") },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                )
            }
        ) { padding ->
            Box(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text("भजन फेला परेन ।")
            }
        }
        return
    }

    val sectionLabel = when (song.section) {
        "chorus" -> "कोरस"
        "child_chorus" -> "बाल कोरस"
        else -> "भजन"
    }

    val songCategories = categories.filter { it.id in song.categoryIds }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "$sectionLabel ${song.numberNepali}",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onToggleKeepScreenOn) {
                        Icon(
                            imageVector = Icons.Default.WbSunny,
                            contentDescription = "Keep screen on",
                            tint = if (keepScreenOn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onToggleFavorite) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = {
                        val shareText = buildString {
                            appendLine("$sectionLabel ${song.numberNepali} (${song.number})")
                            if (!song.englishTitle.isNullOrBlank()) appendLine("(${song.englishTitle})")
                            val meta = listOfNotNull(
                                song.scale?.let { "स्केल: $it" },
                                song.rhythm?.let { "ताल: $it" }
                            ).joinToString(" | ")
                            if (meta.isNotEmpty()) appendLine(meta)
                            appendLine()
                            append(song.lyrics)
                        }
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "$sectionLabel ${song.numberNepali} - ${song.title}")
                            putExtra(Intent.EXTRA_TEXT, shareText)
                        }
                        context.startActivity(Intent.createChooser(intent, "भजन सेयर गर्नुहोस्"))
                    }) {
                        Icon(Icons.Default.Share, contentDescription = "Share")
                    }
                }
            )
        },
        bottomBar = {
            BottomAppBar {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilledTonalButton(
                        onClick = { prevSongId?.let(onNavigateToSong) },
                        enabled = prevSongId != null
                    ) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = null)
                        Text("अघिल्लो")
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { onAdjustFontSize(-2f) }) {
                            Icon(Icons.Default.TextDecrease, contentDescription = "Decrease font size")
                        }
                        Text(
                            text = "${fontSizeSp.toInt()}",
                            style = MaterialTheme.typography.labelLarge
                        )
                        IconButton(onClick = { onAdjustFontSize(+2f) }) {
                            Icon(Icons.Default.TextIncrease, contentDescription = "Increase font size")
                        }
                    }

                    FilledTonalButton(
                        onClick = { nextSongId?.let(onNavigateToSong) },
                        enabled = nextSongId != null
                    ) {
                        Text("अर्को")
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 14.dp)
        ) {
            if (!song.englishTitle.isNullOrBlank()) {
                Text(
                    text = song.englishTitle,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.secondary,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(6.dp))
            }

            if (!song.scale.isNullOrBlank() || !song.rhythm.isNullOrBlank() || songCategories.isNotEmpty()) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (!song.scale.isNullOrBlank()) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = "स्केल: ${song.scale}",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                    if (!song.rhythm.isNullOrBlank()) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer
                        ) {
                            Text(
                                text = "ताल: ${song.rhythm}",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                    songCategories.forEach { cat ->
                        SuggestionChip(
                            onClick = {},
                            label = { Text(cat.name, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Render lyrics line-by-line with chorus & stanza emphasis
            val lines = song.lyrics.lines()
            lines.forEach { line ->
                val trimmed = line.trim()
                val isChorusLine = trimmed.startsWith("कोः")
                val isVerseStart = Regex("^[०-९]+\\.").containsMatchIn(trimmed)
                if (isVerseStart || isChorusLine) {
                    Spacer(modifier = Modifier.height(8.dp))
                }
                Text(
                    text = trimmed,
                    fontSize = fontSizeSp.sp,
                    lineHeight = (fontSizeSp * 1.5f).sp,
                    fontWeight = if (isChorusLine) FontWeight.SemiBold else FontWeight.Normal,
                    color = if (isChorusLine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}
