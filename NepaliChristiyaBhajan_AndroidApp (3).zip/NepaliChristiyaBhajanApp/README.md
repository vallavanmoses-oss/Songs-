# नेपाली ख्रीष्टीय भजन (Nepali Christiya Bhajan) — Android App

An offline-ready Android songbook app built with **Kotlin**, **Jetpack Compose**, and **Material 3**, containing all songs from *Nepali Christiya Bhajan* converted to native UTF-8 Devanagari Unicode.

## Included Content (`app/src/main/assets/songs.json`)
- **752 Bhajans** (`भजन`, 1–752) mapped to **32 Topical Categories** (`विषयगत सूची`)
- **329 Choruses** (`कोरस`, 1–329)
- **70 Child Choruses** (`बाल कोरस`, 1–70)
- **The Lord's Prayer** (`प्रभुले सिकाउनुभएको प्रार्थना` / Matt. 6:9–13) in Nepali & English
- Musical **Scale (`स्केल`)**, **Rhythm (`ताल`)**, and **English hymn subtitles** where present

## Features
- Instant offline search by song number (Nepali `१२३` or English `123`), Nepali title/lyrics, or English subtitle
- Section tabs (Bhajans, Choruses, Child Choruses, Favorites) + 32-category topical index filter
- Adjustable lyrics font size (14sp–32sp), Light/Dark mode, Keep Screen On toggle, Favorites persistence (DataStore), and Share lyrics

## How to Build & Run
1. Extract this archive and open the `NepaliChristiyaBhajanApp` folder in **Android Studio** (Ladybug or newer).
2. Let Gradle sync dependencies (Android SDK 35, JDK 17).
3. Click **Run** (`Shift+F10`) to deploy to an Android emulator or device, or **Build > Build Bundle(s) / APK(s) > Build APK(s)** to generate an installable `.apk`.
